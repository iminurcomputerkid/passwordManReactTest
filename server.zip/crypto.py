"""Client-side crypto primitives: Argon2 (hash + KDF) and Fernet.
- Password verification uses Argon2 PasswordHasher (random salt baked in hash string).
- Encryption key derivation uses Argon2id KDF with *per-user* 16-byte salt stored in DB.
"""
from __future__ import annotations
import base64
import os
from dataclasses import dataclass
from typing import Tuple

import pyotp  # type: ignore
from argon2 import PasswordHasher
from argon2.low_level import hash_secret_raw, Type
from cryptography.fernet import Fernet

from config import A2

ph = PasswordHasher()

@dataclass
class KeyMaterial:
    salt: bytes  # 16B
    fernet_key: bytes  # 32B urlsafe base64 for Fernet

# --- Password hashing (for login verifier) ---------------------------------

def hash_password(pw: str) -> str:
    return ph.hash(pw)

def verify_password(pw_hash: str, pw: str) -> bool:
    try:
        return ph.verify(pw_hash, pw)
    except Exception:
        return False

# --- KDF for encryption key -------------------------------------------------

def derive_key(master_password: str, salt: bytes) -> KeyMaterial:
    if len(salt) != 16:
        raise ValueError("salt must be 16 bytes")
    raw = hash_secret_raw(
        secret=master_password.encode("utf-8"),
        salt=salt,
        time_cost=A2.time_cost,
        memory_cost=A2.memory_cost,
        parallelism=A2.parallelism,
        hash_len=A2.hash_len,
        type=Type.ID,
    )
    fkey = base64.urlsafe_b64encode(raw)
    return KeyMaterial(salt=salt, fernet_key=fkey)

# --- Symmetric encryption ---------------------------------------------------

def encrypt_text(fernet_key: bytes, plaintext: str) -> str:
    return Fernet(fernet_key).encrypt(plaintext.encode("utf-8")).decode("utf-8")

def decrypt_text(fernet_key: bytes, ciphertext: str) -> str:
    return Fernet(fernet_key).decrypt(ciphertext.encode("utf-8")).decode("utf-8")

# --- TOTP helpers -----------------------------------------------------------

def new_totp_secret() -> Tuple[str, str]:
    secret = pyotp.random_base32()
    uri = pyotp.totp.TOTP(secret).provisioning_uri(name="SecureASF", issuer_name="SecureASF")
    return secret, uri

def verify_totp(secret: str, code: str) -> bool:
    try:
        return pyotp.TOTP(secret).verify(code, valid_window=1)
    except Exception:
        return False
