from __future__ import annotations
from fastapi import APIRouter, HTTPException, Header, Depends
from pydantic import BaseModel, Field
from typing import Optional, Dict
import secrets
import manager

router = APIRouter(prefix="/api")

# -----------------------------
# Session store (ephemeral, per-process).
# NOTE: If you run multiple workers, use a shared store (Redis) or set workers=1.
# -----------------------------
_SESSIONS: Dict[str, manager.Session] = {}

def _require_session(x_session_token: Optional[str] = Header(None, alias="X-Session-Token")) -> manager.Session:
    if not x_session_token or x_session_token not in _SESSIONS:
        raise HTTPException(status_code=401, detail="Missing or invalid session")
    return _SESSIONS[x_session_token]

def _new_token() -> str:
    # 256-bit token
    return secrets.token_urlsafe(48)

# -----------------------------
# Schemas
# -----------------------------
class RegisterReq(BaseModel):
    username: str
    master_password: str
    recovery_pin: str

class LoginReq(BaseModel):
    username: str
    master_password: str
    totp_code: Optional[str] = None


class LoginResp(BaseModel):
    session_token: str
    username: str
    message: str

class StoreCredReq(BaseModel):
    site: str
    s_username: str = Field(..., description="Site username (plaintext).")
    s_password: str = Field(..., description="Site password (plaintext).")

class GetCredResp(BaseModel):
    site: str
    s_username: str
    s_password: str

class DeleteCredReq(BaseModel):
    site: str
    recovery_pin: str

class AddDocReq(BaseModel):
    doc_name: str = Field(..., min_length=1, max_length=255)
    contents: str

class DeleteDocReq(BaseModel):
    doc_name: str = Field(..., min_length=1, max_length=255)
    recovery_pin: str = Field(..., min_length=4, max_length=128)

class DeleteData(BaseModel):
    recovery_pin: str = Field(..., min_length=4, max_length=128)

class Toggle2FAReq(BaseModel):
    # For disabling 2FA, require master_password OR recovery_pin
    master_password: Optional[str] = None
    recovery_pin: Optional[str] = None

# -----------------------------
# Account endpoints
# -----------------------------
@router.post("/register")
def register(payload: RegisterReq):
    res = manager.register(payload.username, payload.master_password, payload.recovery_pin)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res

@router.post("/login", response_model=LoginResp)
def login(payload: LoginReq):
    sess, res = manager.login(payload.username, payload.master_password, payload.totp_code)
    if not sess:
        raise HTTPException(status_code=401, detail=res.get("error", "Login failed"))
    token = _new_token()
    _SESSIONS[token] = sess
    return LoginResp(session_token=token, username=sess.username, message=res["message"])

@router.post("/logout")
def logout(sess: manager.Session = Depends(_require_session), x_session_token: str = Header(..., alias="X-Session-Token")):
    _SESSIONS.pop(x_session_token, None)
    return {"message": "Logged out"}


# -----------------------------
# Vault: Site credentials
# -----------------------------
@router.post("/vault/site")
def store_credentials(payload: StoreCredReq, sess: manager.Session = Depends(_require_session)):
    res = manager.add_credentials(sess, payload.site, payload.s_username, payload.s_password)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res

@router.get("/vault/site/{site}", response_model=GetCredResp)
def get_credentials(site: str, sess: manager.Session = Depends(_require_session)):
    res = manager.get_credentials(sess, site)
    if "error" in res:
        raise HTTPException(status_code=404, detail=res["error"])
    return GetCredResp(**res)

@router.get("/vault/sites")
def get_all_sites(sess: manager.Session = Depends(_require_session)):
    return manager.get_all_sites(sess.username)

@router.delete("/vault/site")
def delete_credentials(payload: DeleteCredReq, sess: manager.Session = Depends(_require_session)):
    # Require recovery PIN for destructive delete
    res = manager.delete_credentials(sess.username, payload.site, payload.recovery_pin)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res
# --- Secure Docs: routes ------------------------------------------------------
@router.post("/secure-docs")
def add_or_update_secure_doc(
    payload: AddDocReq,
    sess: manager.Session = Depends(_require_session),
):
    res = manager.add_secure_doc(sess, payload.doc_name, payload.contents)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res

@router.get("/secure-docs")
def list_secure_docs(
    sess: manager.Session = Depends(_require_session),
):
    # Returns: {"documents": ["doc1", "doc2", ...]}
    return manager.get_all_docs(sess.username)

@router.get("/secure-docs/{doc_name}")
def get_secure_doc(
    doc_name: str,
    sess: manager.Session = Depends(_require_session),
):
    res = manager.get_secure_doc(sess, doc_name)
    if "error" in res:
        raise HTTPException(status_code=404, detail=res["error"])
    return res

@router.delete("/secure-docs")
def delete_secure_doc(
    payload: DeleteDocReq,
    sess: manager.Session = Depends(_require_session),
):
    res = manager.delete_secure_doc(sess.username, payload.doc_name, payload.recovery_pin)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res


# --- Account: delete all user data -------------------------------------------
@router.post("/account/delete")
def delete_all_user_data(
    payload: DeleteData,
    sess: manager.Session = Depends(_require_session),
):
    res = manager.delete_all_data(sess.username, payload.recovery_pin)
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res
# -----------------------------
# 2FA (TOTP)
# -----------------------------
# /2fa/enable
@router.post("/2fa/enable")
def enable_2fa(sess: manager.Session = Depends(_require_session)):
    res = manager.enable_2fa(sess)           # <-- pass Session, not two args
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res

# /2fa/disable
@router.post("/2fa/disable")
def disable_2fa(payload: Toggle2FAReq, sess: manager.Session = Depends(_require_session)):
    if not (payload.master_password or payload.recovery_pin):
        raise HTTPException(status_code=400, detail="Provide master_password or recovery_pin")
    res = manager.disable_2fa(               # <-- now accepts both
        sess.username,
        payload.master_password,
        payload.recovery_pin,
    )
    if "error" in res:
        raise HTTPException(status_code=400, detail=res["error"])
    return res