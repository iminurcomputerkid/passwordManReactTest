# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
#from server.routes import router
from routes import router


app = FastAPI(title="pwManAPI")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[],  #no domains
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type","X-Session-Token"],
)

app.include_router(router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000)
