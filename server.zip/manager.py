"""High-level client manager that owns auth, KDF, and CRUD against Azure MySQL.
All sensitive fields are encrypted client-side. The DB stores only ciphertexts
(or hash strings for verifiers) plus minimal metadata.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional, Tuple
import os

import db
from crypto import (
    hash_password, verify_password, derive_key,
    encrypt_text, decrypt_text,
    new_totp_secret, verify_totp,
)

LOCKOUT_THRESHOLD = 5         # lock begins on the 5th wrong attempt
BASE_LOCK_SECS = 300          # 5 minutes at threshold
MAX_LOCK_SECS = 3600 * 24     # optional cap (24h)

@dataclass
class Session:
    username: str
    fernet_key: bytes  # for vault ops


#utils, converts delta time to mins and seconds for lockout
def _pretty_remaining(now, until):
    """Return a short 'Xm Ys' style countdown."""
    rem = int(max(0, (until - now).total_seconds()))
    h, rem = divmod(rem, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m}m {s}s"
    if m:
        return f"{m}m {s}s"
    return f"{s}s"
# --- Account lifecycle ------------------------------------------------------

def register(username: str, master_password: str, recovery_pin: str) -> dict:
    # Existence check
    row = db.fetchone("SELECT username FROM users WHERE username=%s", (username,))
    if row:
        return {"error": "Username already exists"}

    # Prepare crypto material
    pw_hash = hash_password(master_password)
    pin_hash = hash_password(recovery_pin)
    salt = os.urandom(16)

    ts = db.now_ts()
    db.execute(
        """
        INSERT INTO users (username, password_hash, recovery_pin_hash, salt, wrong_attempts, locked_until,
                           totp_enabled, totp_secret_enc, created_at, updated_at)
        VALUES (%s,%s,%s,%s,0,NULL,FALSE,NULL,%s,%s)
        """,
        (username, pw_hash, pin_hash, salt, ts, ts),
    )
    return {"message": "Registered successfully"}

def _compute_lock_until(now, wrong_attempts: int):
    """
    wrong_attempts is the *current* consecutive-failure count (since last success).
    Lock starts at attempt #LOCKOUT_THRESHOLD and doubles thereafter.
    """
    over = max(0, wrong_attempts - LOCKOUT_THRESHOLD)  # 0 on 5th fail, 1 on 6th, etc.
    if wrong_attempts < LOCKOUT_THRESHOLD:
        return None
    secs = BASE_LOCK_SECS * (2 ** over)                # 5m, 10m, 20m, 40m...
    secs = min(secs, MAX_LOCK_SECS)
    return now + timedelta(seconds=secs)

def login(username: str, master_password: str, totp_code: Optional[str] = None) -> Tuple[Optional[Session], dict]:
    row = db.fetchone(
        """
        SELECT password_hash, salt, wrong_attempts, locked_until,
               totp_enabled, totp_secret_enc
        FROM users WHERE username=%s
        """,
        (username,),
    )
    if not row:
        return None, {"error": "Invalid username or password."}

    pw_hash, salt, wrong_attempts, locked_until, totp_enabled, totp_secret_enc = row
    wrong_attempts = int(wrong_attempts or 0)

    # Enforce existing lockout window
    now = db.now_ts()
    if locked_until and now < locked_until:
        return None, {"error": f"User locked out. Try again in {_pretty_remaining(now, locked_until)}."}
    
    # Password check
    if not verify_password(pw_hash, master_password):
        wrong_attempts += 1
        until = _compute_lock_until(now, wrong_attempts)
        db.execute(
            "UPDATE users SET wrong_attempts=%s, locked_until=%s, updated_at=%s WHERE username=%s",
            (wrong_attempts, until, now, username),
        )
        if until:
            return None, {
                "reason": "too_many_attempts",
                "locked_until": until.isoformat() + "Z",
                "retry_after": _pretty_remaining(now, until)
            }   
        return None, {"error": "Invalid username or password."}

    # DO NOT reset counters yet. Only reset after full success (incl. TOTP).
    if bool(totp_enabled):
        if not totp_code:
            # Don't increment on "missing code" UX case; just require it.
            return None, {"error": "2FA required"}

        # Decrypt TOTP secret with key derived from the (now-verified) master password
        km = derive_key(master_password, salt)
        try:
            secret = decrypt_text(km.fernet_key, totp_secret_enc)
        except Exception:
            return None, {"error": "Corrupt 2FA secret"}

        if not verify_totp(secret, totp_code):
            # Extend the SAME lockout to TOTP failures
            wrong_attempts += 1
            until = _compute_lock_until(now, wrong_attempts)
            db.execute(
                "UPDATE users SET wrong_attempts=%s, locked_until=%s, updated_at=%s WHERE username=%s",
                (wrong_attempts, until, now, username),
            )
            if until:
                return None, {
                "reason": "too_many_attempts",
                "locked_until": until.isoformat() + "Z",
                "retry_after": _pretty_remaining(now, until)
                }   
            return None, {"error": "Invalid or expired 2FA code"}

    # Full success → now reset lockout counters
    db.execute(
        "UPDATE users SET wrong_attempts=0, locked_until=NULL, updated_at=%s WHERE username=%s",
        (now, username),
    )

    km = derive_key(master_password, salt)
    return Session(username=username, fernet_key=km.fernet_key), {"message": "Login successful"}

def enable_2fa(sess: Session) -> dict:
    # Check current state first
    row = db.fetchone(
        "SELECT totp_enabled FROM users WHERE username=%s",
        (sess.username,),
    )
    if not row:
        return {"error": "User not found"}
    if bool(row[0]): #if entry in totp_enabled (meaning totp_enabled 1)
        # Don’t rotate silently; require explicit disable step
        return {"error": "2FA already enabled. Disable 2FA before enabling again."}

    # Proceed with first-time enrollment
    secret, uri = new_totp_secret()
    enc = encrypt_text(sess.fernet_key, secret)
    db.execute(
        "UPDATE users SET totp_enabled=TRUE, totp_secret_enc=%s, updated_at=%s WHERE username=%s",
        (enc, db.now_ts(), sess.username),
    )
    return {"message": "2FA enabled", "totp_secret": secret, "provisioning_uri": uri}

def disable_2fa(username: str,
                master_password: Optional[str],
                recovery_pin: Optional[str]) -> dict:
    row = db.fetchone(
        "SELECT password_hash, recovery_pin_hash FROM users WHERE username=%s",
        (username,),
    )
    if not row:
        return {"error": "User not found"}
    pw_hash, pin_hash = row

    ok = False
    if master_password:
        ok = verify_password(pw_hash, master_password) or ok
    if recovery_pin:
        ok = verify_password(pin_hash, recovery_pin) or ok
    if not ok:
        return {"error": "Invalid master password or recovery PIN"}

    db.execute(
        "UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL, updated_at=%s WHERE username=%s",
        (db.now_ts(), username),
    )
    return {"message": "2FA disabled"}

def delete_all_data(username: str, recovery_pin: str) -> dict:
    row = db.fetchone("SELECT recovery_pin_hash FROM users WHERE username=%s", (username,))
    if not row:
        return {"error": "User not found"}
    if not verify_password(row[0], recovery_pin):
        return {"error": "Invalid recovery PIN"}
    db.execute("DELETE FROM users WHERE username=%s", (username,))
    return {"message": "All data deleted"}

# --- Vault: Site credentials -----------------------------------------------

def add_credentials(sess: Session, site: str, s_username: str, s_password: str) -> dict:
    enc_user = encrypt_text(sess.fernet_key, s_username)
    enc_pass = encrypt_text(sess.fernet_key, s_password)
    ts = db.now_ts()
    db.execute(
        """
        INSERT INTO site (username, site, username_enc, password_enc, created_at, updated_at)
        VALUES (%s,%s,%s,%s,%s,%s)
        ON DUPLICATE KEY UPDATE username_enc=VALUES(username_enc), password_enc=VALUES(password_enc), updated_at=VALUES(updated_at)
        """,
        (sess.username, site, enc_user, enc_pass, ts, ts),
    )
    return {"message": "Credentials stored"}

def get_credentials(sess: Session, site: str) -> dict:
    row = db.fetchone(
        "SELECT username_enc, password_enc FROM site WHERE username=%s AND site=%s",
        (sess.username, site),
    )
    if not row:
        return {"error": "Not found"}
    user = decrypt_text(sess.fernet_key, row[0])
    pwd = decrypt_text(sess.fernet_key, row[1])
    return {"site": site, "s_username": user, "s_password": pwd}

def get_all_sites(username: str) -> dict:
    rows = db.fetchall("SELECT site FROM site WHERE username=%s ORDER BY site", (username,))
    return {"sites": [r[0] for r in rows]}

def delete_credentials(username: str, site: str, recovery_pin: str) -> dict:
    row = db.fetchone("SELECT recovery_pin_hash FROM users WHERE username=%s", (username,))
    if not row or not verify_password(row[0], recovery_pin):
        return {"error": "Invalid PIN or user"}
    db.execute("DELETE FROM site WHERE username=%s AND site=%s", (username, site))
    return {"message": "Deleted"}

# --- Vault: Secure documents -----------------------------------------------

def add_secure_doc(sess: Session, doc_name: str, contents: str) -> dict:
    enc = encrypt_text(sess.fernet_key, contents)
    ts = db.now_ts()
    db.execute(
        """
        INSERT INTO secure_docs (username, doc_name, contents_enc, created_at, updated_at)
        VALUES (%s,%s,%s,%s,%s)
        ON DUPLICATE KEY UPDATE contents_enc=VALUES(contents_enc), updated_at=VALUES(updated_at)
        """,
        (sess.username, doc_name, enc, ts, ts),
    )
    return {"message": "Document stored"}

def get_secure_doc(sess: Session, doc_name: str) -> dict:
    row = db.fetchone(
        "SELECT contents_enc FROM secure_docs WHERE username=%s AND doc_name=%s",
        (sess.username, doc_name),
    )
    if not row:
        return {"error": "Not found"}
    return {"doc_name": doc_name, "doc_contents": decrypt_text(sess.fernet_key, row[0])}

def get_all_docs(username: str) -> dict:
    rows = db.fetchall("SELECT doc_name FROM secure_docs WHERE username=%s ORDER BY doc_name", (username,))
    return {"documents": [r[0] for r in rows]}

def delete_secure_doc(username: str, doc_name: str, recovery_pin: str) -> dict:
    row = db.fetchone("SELECT recovery_pin_hash FROM users WHERE username=%s", (username,))
    if not row or not verify_password(row[0], recovery_pin):
        return {"error": "Invalid PIN or user"}
    db.execute("DELETE FROM secure_docs WHERE username=%s AND doc_name=%s", (username, doc_name))
    return {"message": "Deleted"}
