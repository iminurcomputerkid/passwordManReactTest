"""Thin MySQL wrapper with automatic schema creation and typed helpers.
Uses mysql-connector-python with SSL verification (strongly recommended on Azure).
"""
from __future__ import annotations
from mysql.connector import pooling
from typing import Any, Iterable, Optional, Tuple
from contextlib import contextmanager
from datetime import datetime

from config import DB

# --- Connection pool -------------------------------------------------------

_pool = pooling.MySQLConnectionPool(
    pool_name="secure_asf_pool",
    pool_size=5,
    host=DB.host,
    port=DB.port,
    database=DB.database,
    user=DB.user,
    password=DB.password,
    ssl_ca=DB.ssl_ca,
    ssl_verify_cert=True if DB.ssl_ca else False,
)

@contextmanager
def conn_cursor():
    cnx = _pool.get_connection()
    try:
        cur = cnx.cursor()
        try:
            yield cnx, cur
            cnx.commit()
        finally:
            cur.close()
    finally:
        cnx.close()

# --- Schema bootstrap ------------------------------------------------------

SCHEMA_STATEMENTS: Tuple[str, ...] = (
    # Users
    """
    CREATE TABLE IF NOT EXISTS users (
        username            VARCHAR(255) PRIMARY KEY,
        password_hash       TEXT NOT NULL,
        recovery_pin_hash   TEXT NOT NULL,
        salt                VARBINARY(16) NOT NULL,
        wrong_attempts      INT NOT NULL DEFAULT 0,
        locked_until        DATETIME NULL,
        totp_enabled        BOOLEAN NOT NULL DEFAULT FALSE,
        totp_secret_enc     TEXT NULL,
        created_at          DATETIME NOT NULL,
        updated_at          DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    # Site credentials vault
    """
    CREATE TABLE IF NOT EXISTS site (
        id              BIGINT AUTO_INCREMENT PRIMARY KEY,
        username        VARCHAR(255) NOT NULL,
        site            VARCHAR(255) NOT NULL,
        username_enc    TEXT NOT NULL,
        password_enc    TEXT NOT NULL,
        created_at      DATETIME NOT NULL,
        updated_at      DATETIME NOT NULL,
        UNIQUE KEY uniq_user_site (username, site),
        CONSTRAINT fk_site_user FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    # Secure docs
    """
    CREATE TABLE IF NOT EXISTS secure_docs (
        id              BIGINT AUTO_INCREMENT PRIMARY KEY,
        username        VARCHAR(255) NOT NULL,
        doc_name        VARCHAR(255) NOT NULL,
        contents_enc    LONGTEXT NOT NULL,
        created_at      DATETIME NOT NULL,
        updated_at      DATETIME NOT NULL,
        UNIQUE KEY uniq_user_doc (username, doc_name),
        CONSTRAINT fk_docs_user FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
)

def bootstrap_schema() -> None:
    with conn_cursor() as (_, cur):
        for stmt in SCHEMA_STATEMENTS:
            cur.execute(stmt)

bootstrap_schema()

# --- Generic helpers -------------------------------------------------------

def execute(query: str, params: Optional[Iterable[Any]] = None) -> None:
    with conn_cursor() as (_, cur):
        cur.execute(query, tuple(params or ()))

def fetchone(query: str, params: Optional[Iterable[Any]] = None) -> Optional[Tuple[Any, ...]]:
    with conn_cursor() as (_, cur):
        cur.execute(query, tuple(params or ()))
        row = cur.fetchone()
        return row

def fetchall(query: str, params: Optional[Iterable[Any]] = None) -> list[Tuple[Any, ...]]:
    with conn_cursor() as (_, cur):
        cur.execute(query, tuple(params or ()))
        rows = cur.fetchall()
        return list(rows)

# Convenience timestamp

def now_ts() -> datetime:
    return datetime.utcnow()
