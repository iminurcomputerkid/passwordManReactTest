"""Client configuration for Azure MySQL + crypto parameters.
Loads from environment (optionally .env via python-dotenv).
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv(Path(__file__).parent / ".env")
except Exception:
    pass

@dataclass(frozen=True)
class DBConfig:
    host: str = os.getenv("MYSQL_HOST", "")
    port: int = int(os.getenv("MYSQL_PORT", "3306"))
    database: str = os.getenv("MYSQL_DB", "")
    user: str = os.getenv("MYSQL_USER", "")
    password: str = os.getenv("MYSQL_PASSWORD", "")
    ssl_ca: str | None = os.getenv("MYSQL_SSL_CA")

@dataclass(frozen=True)
class Argon2Config:
    time_cost: int = int(os.getenv("ARGON2_TIME_COST", "3"))
    memory_cost: int = int(os.getenv("ARGON2_MEMORY_COST", "65536"))
    parallelism: int = int(os.getenv("ARGON2_PARALLELISM", "4"))
    hash_len: int = 32

DB = DBConfig()
A2 = Argon2Config()

# Basic sanity checks (fail fast if essential config is missing)
if not (DB.host and DB.user and DB.password):
    raise RuntimeError(
        "MySQL connection env not set. Define MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD (and optionally MYSQL_DB, MYSQL_SSL_CA)."
    )
